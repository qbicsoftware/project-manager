$wnd.life_qbic_AppWidgetSet.runAsyncCallback2('xib(1744,1,sje);_.vc=function quc(){ecc((!Zbc&&(Zbc=new jcc),Zbc),this.a.d)};ece(Zh)(2);\n//# sourceURL=life.qbic.AppWidgetSet-2.js\n')
